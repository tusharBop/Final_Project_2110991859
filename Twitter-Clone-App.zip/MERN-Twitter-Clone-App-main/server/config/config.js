const JWT_SECRET = "twitter-clone-capstone-project-secret";

module.exports = { JWT_SECRET };
